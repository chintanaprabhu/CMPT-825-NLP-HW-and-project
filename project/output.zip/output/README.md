Checking the output files:

We had 3 output files from 3 different models so they did not fit under the size requirements of coursys.
We have provided links below to all 3 csv files which would have to be downloaded

For Logistic Regression - https://csil-git1.cs.surrey.sfu.ca/krutp/nlpclass-1197-g-lexchunkers/blob/a233746e31abb838276756461a5211b1888c4693/project/Log_reg/logReg_submission.csv

For LSTM - https://csil-git1.cs.surrey.sfu.ca/krutp/nlpclass-1197-g-lexchunkers/blob/a233746e31abb838276756461a5211b1888c4693/project/LSTM/LSTM_submission.csv

For CNN - https://csil-git1.cs.surrey.sfu.ca/krutp/nlpclass-1197-g-lexchunkers/blob/a233746e31abb838276756461a5211b1888c4693/project/TextCNN/textCNN_submission.csv

They need to be submitted to Kaggle for getting the AUC score over here - https://www.kaggle.com/c/jigsaw-toxic-comment-classification-challenge/submit