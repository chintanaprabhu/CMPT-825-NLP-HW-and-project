Logistic regression model
Worked on parts of poster